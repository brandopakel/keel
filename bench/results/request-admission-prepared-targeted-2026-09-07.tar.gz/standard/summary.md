| Workload | Arm | Ops/s median (range) | p99 ms median | RSS MiB median | Client CPU warnings | Candidate/baseline ratio (range) |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| cache-read-1m | baseline | 1,860 (1,834–1,886) | 4.383 | 84.38 | 0 | — |
| cache-read-1m | candidate | 1,866 (1,838–1,875) | 4.479 | 85.73 | 0 | 0.998 (0.992–1.018) |
| cache-write-1m | baseline | 1,506 (1,481–1,520) | 5.663 | 95.03 | 0 | — |
| cache-write-1m | candidate | 1,515 (1,482–1,518) | 5.631 | 93.88 | 0 | 1.008 (0.976–1.016) |
| cache-write-pipeline-64 | baseline | 1,284,130 (1,275,600–1,288,449) | 1.671 | 14.53 | 0 | — |
| cache-write-pipeline-64 | candidate | 1,279,558 (1,274,983–1,288,581) | 1.639 | 14.45 | 0 | 0.999 (0.993–1.001) |
