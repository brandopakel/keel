| Workload | Arm | Ops/s median (range) | p99 ms median | RSS MiB median | Client CPU warnings | Candidate/baseline ratio (range) |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| cache-read-1m | baseline | 1,899 (1,843–1,929) | 41.215 | 86.83 | 0 | — |
| cache-read-1m | candidate | 1,858 (1,852–1,963) | 41.215 | 87.12 | 0 | 1.007 (0.966–1.017) |
| cache-write-1m | baseline | 402 (325–450) | 42.239 | 93.59 | 0 | — |
| cache-write-1m | candidate | 354 (293–402) | 42.239 | 93.82 | 0 | 0.830 (0.731–1.239) |
| cache-write-pipeline-64 | baseline | 1,729,223 (1,725,255–1,742,410) | 1.055 | 14.55 | 0 | — |
| cache-write-pipeline-64 | candidate | 1,699,438 (1,666,672–1,714,238) | 1.071 | 14.48 | 0 | 0.979 (0.965–0.992) |
